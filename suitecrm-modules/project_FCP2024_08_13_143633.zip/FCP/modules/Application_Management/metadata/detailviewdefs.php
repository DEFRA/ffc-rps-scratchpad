<?php
$module_name = 'fcrps_Application_Management';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'land_action',
            'studio' => 'visible',
            'label' => 'LBL_LAND_ACTION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'sbi',
            'label' => 'LBL_SBI',
          ),
          1 => 
          array (
            'name' => 'payment_amount',
            'label' => 'LBL_PAYMENT_AMOUNT',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'scheme',
            'label' => 'LBL_SCHEME',
          ),
          1 => 
          array (
            'name' => 'land_parcel_id',
            'label' => 'LBL_LAND_PARCEL_ID',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'application_status',
            'studio' => 'visible',
            'label' => 'LBL_APPLICATION_STATUS',
          ),
          1 => 
          array (
            'name' => 'date_entered',
            'comment' => 'Date record created',
            'label' => 'LBL_DATE_ENTERED',
          ),
        ),
      ),
    ),
  ),
);
;
?>
